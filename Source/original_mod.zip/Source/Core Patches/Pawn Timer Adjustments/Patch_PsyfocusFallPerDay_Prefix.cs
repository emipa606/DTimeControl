﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using RimWorld;
using Verse;

namespace DTimeControl.Core_Patches
{
    [HarmonyPatch(typeof(Pawn_PsychicEntropyTracker))]
    [HarmonyPatch("PsyfocusFallPerDay", MethodType.Getter)]
    class Patch_PsyfocusFallPerDay_Prefix
    {
        public static bool Prefix()
        {
            if (TimeControlBase.partialTick < 1.0)
                return false;
            return true;
        }
    }
}
